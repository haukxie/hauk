var app = getApp()
var that = this;

Page({
  data: {
    bj: ['/images/bj.gif'],
    music: 'http://mp3.qqmusic.cc/yq/107187243.mp3',
    musicphoto: 'http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/aW4Pl.7NtI1BCrrtzyovy2YYN3EZqCBPgQo7JsNneAE!/r/dFYBAAAAAAAA',
    musicname: '琵琶语',
    musicplay: 'listenerButtonPlay',
    swich: '',
    imagexyb: ['http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/UWSjdIWM8doYVe3CbKoa6.omvd4lpfwANSmPiTtGpyE!/r/dEIBAAAAAAAA'],
    weixin: ['http://m.qpic.cn/psb?/V12UVFQr0tUXaE/C14d4eAYQuI.ylSPh3MVmBIKq2qPpv94*y1dLmQXnPc!/b/dDABAAAAAAAA&bo=rgGuAQAAAAARFyA!&rf=viewer_4&t=5'],
    picture1: ['http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/a*K.r7Asyy4ZN5UWqdRAshD*xt55nXMyRYEPwChpsOQ!/r/dGgBAAAAAAAA'],
    picture2: ['http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/sdRBGcSzcoxKEcJ0aBbDI9HJcuhqDOcVJFkSOMMU83U!/r/dDIBAAAAAAAA'],
    picture3: ['http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/cGyp2NEDDG9CHrv7G6DYj*wgeKGa7WcaFDi7qL5I1.4!/r/dGoBAAAAAAAA'],
    /** 
        * 页面配置 
        */
    winWidth: 0,
    winHeight: 0,
    // tab切换  
    currentTab: 0,
  },
  onLoad: function (options) {
    var that = this;

    /** 
     * 获取系统信息 
     */
    wx.getSystemInfo({

      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }

    });
    // 页面初始化 options为页面跳转所带来的参数    
    /**   
     * 监听音乐播放   
     */
    wx.onBackgroundAudioPlay(function () {
      // callback  
      console.log('onBackgroundAudioPlay')
    })
    /**  
     * 监听音乐暂停  
     */
    wx.onBackgroundAudioPause(function () {
      // callback  
      console.log('onBackgroundAudioPause')
    })
    /**  
     * 监听音乐停止  
     */
    wx.onBackgroundAudioStop(function () {
      // callback  
      console.log('onBackgroundAudioStop')
    })
  },
  /** 
     * 滑动切换tab 
     */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /** 
   * 点击tab切换 
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },
  //播放  
  listenerButtonPlay: function () {
    wx.playBackgroundAudio({
      dataUrl: this.data.music,
      title: this.data.musicname,
      //图片地址地址  
      coverImgUrl: this.data.musicphoto,
    })
    this.setData({
      musicplay: 'listenerButtonPause',
      swich: 'ture'
    })
  },
  //监听button暂停按钮  
  listenerButtonPause: function () {
    wx.pauseBackgroundAudio({
    });
    console.log('暂停播放')
    this.setData({
      musicplay: 'listenerButtonPlay',
      swich: ''
    })
  },
  /**  
   * 播放状态  
   */
  listenerButtonGetPlayState: function () {
    wx.getBackgroundAudioPlayerState({
      success: function (res) {
        // success  
        //duration  选定音频的长度（单位：s），只有在当前有音乐播放时返回  
        console.log('duration:' + res.duration)
        console.log('currentPosition:' + res.currentPosition)
        //status    播放状态（2：没有音乐在播放，1：播放中，0：暂停中）  
        console.log('status:' + res.status)
        console.log('downloadPercent:' + res.downloadPercent)
        //dataUrl   歌曲数据链接，只有在当前有音乐播放时返回   
        console.log('dataUrl:' + res.dataUrl)
      },
      fail: function () {
        // fail  
      },
      complete: function () {
        // complete  
      }
    })
  },
  /**  
   * 设置进度  
   */
  listenerButtonSeek: function () {
    wx.seekBackgroundAudio({
      position: 40
    })
  },
  /**  
   * 停止播放  
   */
  listenerButtonStop: function () {
    wx.stopBackgroundAudio({
    })
    console.log('停止播放')
    this.setData({
      musicplay: 'listenerButtonPlay',
      swich: ''
    })
  },
  //切换音乐
  actioncnt: function () {
    var that = this;
    wx.showActionSheet({
      itemList: ['差一步', '你懂得', '盗心贼', '醉赤壁', '琵琶语',],
      itemColor: '#007aff',
      success: function (res) {
        console.log(res.tapIndex)
        if (res.tapIndex === 0) {
          that.cyb();
          that.listenerButtonStop();
        } else if (res.tapIndex === 1) {
          that.ndd();
          that.listenerButtonStop();
        } else if (res.tapIndex === 2) {
          that.dxz();
          that.listenerButtonStop();
        } else if (res.tapIndex === 3) {
          that.zcb();
          that.listenerButtonStop();
        } else if (res.tapIndex === 4) {
          that.ppy();
          that.listenerButtonStop();
        }
      },
      fail: function (res) {
        console.log(res.errMsg)
      },
    })
  },
  cyb: function(){
    this.setData({
      music: 'http://mp3.qqmusic.cc/yq/209378295.mp3',
      musicphoto: 'http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/iioGTqqGzuHF3V7lF6yHRvnSDgWFkSedfWjCH4HjGh0!/r/dDABAAAAAAAA',
      musicname: '差一步',
      swich: '',
    })
  },
  ndd: function () {
    this.setData({
      music: 'http://mp3.qqmusic.cc/yq/1943608.mp3',
      musicphoto: 'http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/z3C1zvPbsAcHayE0GXHsOC6HM*QEIW2iTQ8MQQJRkKc!/r/dDIBAAAAAAAA',
      musicname: '你懂得',
      swich: '',
    })
  },
  dxz: function () {
    this.setData({
      music: 'http://mp3.qqmusic.cc/yq/202116471.mp3',
      musicphoto: 'http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/NOasZFiL47h2kiX3hB8NnLHZBYdtAmE0X7AVmy*WRqw!/r/dDABAAAAAAAA',
      musicname: '盗心贼',
      swich: '',
    })
  },
  zcb: function () {
    this.setData({
      music: 'http://mp3.qqmusic.cc/yq/105388642.mp3',
      musicphoto: 'http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/ijgpY5sTdOUTEqJE1kPCtxcWO1o11CLwavfDLXemgEw!/r/dFYBAAAAAAAA',
      musicname: '醉赤壁',
      swich: '',
    })
  },
  ppy: function () {
    this.setData({
      music: 'http://mp3.qqmusic.cc/yq/107187243.mp3',
      musicphoto: 'http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/aW4Pl.7NtI1BCrrtzyovy2YYN3EZqCBPgQo7JsNneAE!/r/dFYBAAAAAAAA',
      musicname: '琵琶语',
      swich: '',
    })
  },
  //校园帮二维码预览
  previewxyb: function (e) {
    var current = e.target.dataset.src;
    wx.previewImage({
      current: this.data.imagexyb, // 当前显示图片的http链接  
      urls: this.data.imagexyb, // 需要预览的图片http链接列表  
    })
  }, 
  previewkfz: function (e) {
    var current = e.target.dataset.src;
    wx.previewImage({
      urls: this.data.weixin, // 需要预览的图片http链接列表  
    })
  }, 
  // 分享功能
  onShareAppMessage: function (res) {
    console.log("[Console log]:Sharing the app...");
    return {
      desc: '科院小帮手',
      path: 'pages/index/index',
      imageUrl: 'http://r.photo.store.qq.com/psb?/V12UVFQr4DnS3b/Ec7Ic4pX7ezvfSe0ok*cfin5qwOGeBTvcZseqg0vaDk!/r/dPQAAAAAAAAA',
      success: function (res) {
        console.log("[Console log]:Share app success...");
        console.log("[Console log]:" + res.errMsg);
      },
      fail: function (res) {
        console.log("[Console log]:Share app fail...");
        console.log("[Console log]:" + res.errMsg);
      }
    }
  }, 
}) 